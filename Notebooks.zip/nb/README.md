# Vijay's Notebooks and EDHEC Risk Kit Code
(c) Vijay Vaidyanathan 2019

Here are my Notebooks and Code files I developed for the EDHEC/Coursera course for you to use as a reference.

You will also need to have the data folder unpacked into the same folder as these in order to load the data in.

This is version 01, I will update as bugs/issues are reported.
